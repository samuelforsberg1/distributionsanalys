%% Function Name: create_matpower_structure
% Description: Read the load data and add it to the specific bus which it
% is related to. Note that the load data will be mapped to the unique mpc 
% index of the bus it is related to.
%
% Inputs:
%     bus data - bus_ data
%
% Outputs:
%     load_profiles - load profile for each bus and relate to the unique
%     mpc idx of the bus it is related to.
%
% $Revision: R2023b$ 
% $Author: Ludvig Syrén, ludvig.syren@angstrom.uu.se$
% $Date: November 27, 2024$
%---------------------------------------------------------
function load_profiles = load_load_profiles(bus_data)
    load_profiles = containers.Map('KeyType','double', 'ValueType','any');
    for i = 1:height(bus_data)
        bus_name = strrep(bus_data.BUS_I(i),'.','');
        bus_name = strrep(bus_name,'v','');
        bus_name = string(bus_name);
        %load_profile_file = strcat(bus_name, '.txt');
        load_profile_file = load('Load/loads.mat');%strcat("Load\",load_profile_file);
        if isfield(load_profile_file,bus_name)
            load_profile = load_profile_file.(bus_name);
            load_profiles(i) = load_profile;
        else
            load_profiles(i) = zeros(26690,1);
        end
    end
end