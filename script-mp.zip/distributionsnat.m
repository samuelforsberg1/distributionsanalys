%function [] = distributionsnat()
%% Info
% Distributionsnätskursen

close all;
clc;
clear all;
tic;

%--------------------------------------------------------------------------
%% 1. Define contants, solver and other parameters
solver = 'NR';          % Solver used in runpf {'NR','FDXB','FDBX','GS'}
qLim = 1;               % Enforce generator Q limits? (0=no, 1=yes)
flatStart = 0;          % Apply flat start in every time step (0=no, 1=yes)
idxPV = 1;
%--------------------------------------------------------------------------
%% 2. Load the power system case and identify slack bus indices
%{
Cases:
r1 - Left side of grid
r2 - Right side of grid
r1r2s1 - Complete grid fed from left
r1r2s2 - Complete grid fed from right
%}
%branch_new.csv contains an impedance estimation for each line
[mpc, bus_data, branch_data] = csv_to_matpower_case("bus.csv", "branch_new.csv","r1");
[unique_buses, ~, bus_indices] = unique(bus_data.BUS_I);
% Adding loads
correlation_table = table(bus_indices, unique_buses);

mpc.bus(:,8) = 1;
%Lägg alla bussar i samma loss zone
mpc.bus(:,11)=1;



busIdxSlack = find(mpc.bus(:,2)==3);              % Slack bus index in mpc.bus
busIdxSlack
genIdxSlack = (find(mpc.gen(:,1)==busIdxSlack));  % Slack bus index in mpc.gen
busIdxSlack
%genIdxSlack = genIdxSlack(1);                     % If there are more than one generator

%--------------------------------------------------------------------------
%% 4. Read input load data (power consumption and production)
%obs. här är det användbart om man både läser in en tidsvektor och
%effektbehovs/produktionsvektor. Antingen läser man in detta från en och
%samma fil till alla EVs och PVs eller så läser man in från en fil i taget
%till respektive EV och PV.

% EV data
%variableA = load('filename.mat');

% PV data
PV_data_raw = readtable("Generation\FINE-PVgen-main\FINE-PVgen-main\PVgenerator\PV generation.xlsx");
%This data is recorded hourly for six years. 1/1/2015 --> 31/12/2020. 

% A complete year is 8760hr --> 4000 ~ June. --> 730hr=1 month
G_start=4000;
G_end=4730;

%Load data 2019-03-01 to 2022-03-16
L_start = 730*3; %Beg. of June
L_end = 730*4+1;%End of June

%Here timeVector ranges from 1:length(PV_data)
%Every hour over a month
timeVector = 1:731;
%--------------------------------------------------------------------------
%% 6. Solve the power flow at each time step

loadBusVoltage = zeros(730,sum(mpc.bus(:,2)==1)); %Pre allocation
pvBusVoltage = zeros(730,sum(mpc.bus(:,2)==2));

%mpc.gen(genIdxSlack,4)    = qMaxSlack;         % Maximum reactive power supply at slack bus (unlimited)
%mpc.gen(genIdxSlack,5)    = qMinSlack;         % Minimum reactive power supply at slack bus (unlimited)
%Add PV at

PV_gen1 = 54; %r1v0.415b41
PV_gen2 = 32; %r1v0.415b19
PV_gen3 = 33; %r1v0.415b20

keyset = keys(mpc.load_profiles);
mpc.gen = [mpc.gen; 
    PV_gen1     0     0    10   -10     1    10     1    1000     0     0     0     0     0     0     0     0     0     0     0     0;
    PV_gen2     0     0    10   -10     1    10     1    1000     0     0     0     0     0     0     0     0     0     0     0     0;
    PV_gen3     0     0    10   -10     1    10     1    1000     0     0     0     0     0     0     0     0     0     0     0     0];
mpopt = mpoption('out.all',0,'verbose',0,'pf.alg',solver,'pf.enforce_q_lims',qLim);  % Stop printout, full Newton Raphson method, respect Q-limits or not
gridFlatStart = runpf(mpc,mpopt);         % Flat start case data
for indT = G_start:G_end                          % Loop through all time steps
    t = indT;

    if flatStart == 1
        mpc = gridFlatStart;  % Apply flat start in every time step
    end
    
    mpc.gen(2,2) = PV_data_raw.Rakkestad(indT)/1000;          % Set PV power generation at time step t
    mpc.gen(3,2) = PV_data_raw.Rakkestad(indT)/1000;
    mpc.gen(4,2) = PV_data_raw.Rakkestad(indT)/1000;% Set PV power generation at time step t
    %mpc.bus(L_start,3:4) = mpc.load_profiles();        % Set EV power consumption at time step t
    for j=1:length(mpc.bus)
        load_profile = mpc.load_profiles(j); %bus
        load = load_profile(L_start); %load of bus at current timestep
        mpc.bus(j,3) = load/1000;
        mpc.bus(j,4) = load/1000;

        if j==32
            mpc.bus(j,4) = 0.45*load/1000;
        end
    end
    L_start=L_start+1;
    %ind0 = find(mpc.gen(:,2)==0);           % Deactivate generators with P==0
    %mpc.gen(ind0,8) = 0;                    % Gen status = 0
    %mpc.gen(genIdxSlack,8) = 1;             % Re-activate slack bus generator

    % ---------------------------------------------------------------------
    % Solve the power flow case at time step t
    results = runpf(mpc,mpopt);



    %% 6.6 Save data for converged and non converged solutions
    if results.success == 1    % If we have found a converged solution
        pvBusVoltage(indT-G_start+1,:) = results.bus(mpc.gen(2,1),8)';     % PV bus voltage (PV parks) in pu at time step t
        loadBusVoltage(indT-G_start+1,:) = results.bus(mpc.bus(:,2)==1,8)';        % PQ bus voltage (load buses) in pu at time step t
        
        mpc = results;  % Aviod flat start in next time step
        mpc.gen(:,8) = 1;                       % Set all generators' status = 1 (active)
    else
        pvBusVoltage(indT-G_start+1,:) = NaN;     % Bus voltage (PV parks) in pu at time step t (non converged solution)
        loadBusVoltage(indT-G_start+1,:) = NaN;     % Bus voltage (load buses) in pu at time step t (non converged solution)

        mpc = gridFlatStart;  % Apply a flat start in next time step
        disp("Cannot find a converged solution for time step "+num2str(t)+". Applying flat start.")
    end

end

%--------------------------------------------------------------------------
%% 7. Calculate results
% Code to calculate and process results

%--------------------------------------------------------------------------
%% 8. Plots and final printout

% tex. bus spänning som funktion av tid etc...
figLoadBusVoltage = figure;
hold on
%plot(timeVector,loadBusVoltage(:,39));
%plot(timeVector,loadBusVoltage(:,45));
%plot(timeVector,loadBusVoltage(:,5));
plot(timeVector,loadBusVoltage(:,PV_gen1-1));
plot(timeVector,loadBusVoltage(:,PV_gen2-1))
plot(timeVector,loadBusVoltage(:,PV_gen3-1));
plot(timeVector,loadBusVoltage(:,32-1));
xlabel('Time');
ylabel('Bus voltage magnitude (load buses) [pu]');
hold off
legend('r1v0.415b41','r1v0.415b19', 'r1v0.415b20', 'loadBus' )

saveas(figLoadBusVoltage,'figLoadBusVoltage.jpg','jpeg');
%{
plot(timeVector,loadBusVoltage(:,39));
plot(timeVector,loadBusVoltage(:,45));
plot(timeVector,loadBusVoltage(:,5));
%}

simTime = toc;
disp(['Simulation took ',num2str(simTime),' seconds to complete.'])

% Save data in .mat file
%fileName = ['results',caseFile,num2str(year),'WP',num2str(windPen),'UCUT',num2str(Ucutin),'SUT',num2str(startUpTime)];
%save(fileName);
%end