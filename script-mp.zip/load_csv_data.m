%% Function Name: load_csv_data
%
% Description: Read and store the branch and bus data
%
% Inputs:
%     csv file with bus data
%     csv file with branch data
%
% $Revision: R2023b$ 
% $Author: Ludvig Syrén, ludvig.syren@angstrom.uu.se$
% $Date: November 27, 2024$
%---------------------------------------------------------
function [bus_data, branch_data, bus_data_cpy, branch_data_cpy] = load_csv_data(bus_csv, branch_csv)
    bus_data = readtable(bus_csv);
    branch_data = readtable(branch_csv);
    bus_data_cpy = bus_data;
    branch_data_cpy = branch_data;
end